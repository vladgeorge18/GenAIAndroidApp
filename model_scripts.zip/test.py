#!/usr/bin/env python3

# test.py script  


import pathlib, torch
from torchvision import transforms
from torchvision.utils import save_image
from PIL import Image
import argparse
from model_style import StyTr2             



# CLI argmunets

parser = argparse.ArgumentParser()

parser.add_argument('--content', type=str,
                    help='File path to the content image')
parser.add_argument('--style', type=str,
                    help='File path to the style image')
parser.add_argument('--output', type=str, default='output',
                    help='Directory to save the output image')
parser.add_argument('--ckpt', type=str, default=None,
                    help='Path to the model checkpoint')
parser.add_argument('--device', type=str, default=None,
                    help='Device to use: cuda or cpu')


args = parser.parse_args()


_DEFAULT_CKPT = "style_experiments/run11/stytr2_best.pth"
_DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"
_MODEL        = None                       # loaded once, kept in memory


def _make_transform():
    
    return transforms.Compose([
        transforms.Resize((512, 512)),
        transforms.ToTensor(),
    ])


def _get_model(ckpt=_DEFAULT_CKPT, device=_DEVICE):

    # load and cache the StyTr network and checkpoint.
    global _MODEL
    if _MODEL is None:
        model = StyTr2().to(device)
        ckpt_data = torch.load(ckpt, map_location=device)
        model.load_state_dict(ckpt_data.get("state_dict", ckpt_data))
        model.eval()
        _MODEL = model
    return _MODEL


# Do the inference

@torch.inference_mode()
def stylise(
    content_img,             # path to content image
    style_img,               # path to style image
    out_dir,                 # path to output dir
    ckpt_path    = _DEFAULT_CKPT,
    device       = _DEVICE,
):
    


    device   = torch.device(device)
    tfm      = _make_transform()
    out_dir  = pathlib.Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # load images 
    c_pil   = Image.open(content_img).convert("RGB")
    s_pil   = Image.open(style_img   ).convert("RGB")
    w_orig, h_orig = c_pil.size                  

    content = tfm(c_pil).unsqueeze(0).to(device)
    style   = tfm(s_pil).unsqueeze(0).to(device)

    # do the forward pass 
    model   = _get_model(ckpt_path, device)
    output  = model(content, style, mode="test")   

    # interpolate output and save reuslt
    
    out_pil = transforms.ToPILImage()(output.squeeze(0).cpu())

    # resize back to original size with Lanczos
    out_pil = out_pil.resize((w_orig, h_orig), resample=Image.LANCZOS)

    out_name = (
        f"{pathlib.Path(content_img).stem}_{pathlib.Path(style_img).stem}.jpg"
    )
    save_path = out_dir / out_name
    out_pil.save(save_path)

    return save_path




ckpt = args.ckpt if args.ckpt is not None else _DEFAULT_CKPT
device = args.device if args.device is not None else _DEVICE
saved_path = stylise(
    args.content,
    args.style,
    out_dir=args.output,
    ckpt_path=ckpt,
    device=device,
)
print(f"Stylised image saved to {saved_path}")
