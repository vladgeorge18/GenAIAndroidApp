#!/usr/bin/env python

#  train.py – StyTr training script 

import argparse, math, os, torch
import torch.utils.data as data
from torchvision import transforms
from torchvision.datasets import ImageFolder
from torchvision.utils import save_image
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
from PIL import Image
import pandas as pd
import csv, pathlib, datetime

from model_style import StyTr2                           
from style_utils import next_run_dir

# CLI arguments
p = argparse.ArgumentParser()
p.add_argument("--content_dir", default="coco/train2017")      
p.add_argument("--style_dir",   default="wikiart")
p.add_argument("--val_csv",     default="style_transfer_val_pairs_good2.csv")  
p.add_argument("--logdir",      default="style_runs/stytr2")
p.add_argument("--batch",       type=int,   default=8)
p.add_argument("--lr",          type=float, default=5e-4)
p.add_argument("--steps",       type=int,   default=160000)
p.add_argument("--warmup",      type=int,   default=10000)
p.add_argument("--save_every",  type=int,   default=10000)
p.add_argument("--val_every",   type=int,   default=10000)
p.add_argument("--lr_decay", type=float, default=1e-5) 
args = p.parse_args()

exp_run_dir  = next_run_dir("style_experiments")
log_run_dir  = next_run_dir("style_runs")

print(f"Checkpoint dir : {exp_run_dir}")
print(f"TensorBoard dir : {log_run_dir}")


args.logdir = log_run_dir.as_posix()

# Learning Rate scheduler 
def adjust_learning_rate(optimizer, step):
    
    lr = 2e-4 / (1.0 + args.lr_decay * (step - 10_000))
    for pg in optimizer.param_groups:
        pg["lr"] = lr


def warmup_learning_rate(optimizer, step):
    
    #Linear  warm-up:

    lr = args.lr * 0.1 * (1.0 + 3e-4 * step)
    for pg in optimizer.param_groups:
        pg["lr"] = lr

# Data Transforms
train_tfm = transforms.Compose([
    transforms.Resize(512),
    transforms.RandomCrop(256),
    transforms.ToTensor()
])

# Dataset initialization
content_ds = ImageFolder(args.content_dir, train_tfm)
style_ds   = ImageFolder(args.style_dir,   train_tfm)

# Initialize dataloader with infinite sampler
def infinite(loader):
    while True:
        for x, _ in loader:
            yield x

content_iter = infinite(data.DataLoader(
        content_ds, batch_size=args.batch, shuffle=True,
        num_workers=4, pin_memory=True, drop_last=True))
style_iter   = infinite(data.DataLoader(
        style_ds,   batch_size=args.batch, shuffle=True,
        num_workers=4, pin_memory=True, drop_last=True))


# Initalize model and optimizer
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model  = StyTr2().to(device)


decay, no_decay = [], []
for n, p in model.named_parameters():
    if not p.requires_grad:
        continue
    (no_decay if p.ndim == 1 or n.endswith("bias") else decay).append(p)

opt = torch.optim.AdamW(
        [{"params": decay,    "weight_decay": 1e-4},
         {"params": no_decay, "weight_decay": 0.0}],
        lr=args.lr, betas=(0.9, 0.99))



# Validation Step prerequisites
val_df   = pd.read_csv(args.val_csv)            
val_tfm  = transforms.Compose([
    transforms.Resize(512),
    transforms.CenterCrop(256),
    transforms.ToTensor()
])

class ValPairDataset(Dataset):
    def __init__(self, csv_path, transform):
        self.df  = pd.read_csv(csv_path)
        self.tfm = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        content = self.tfm(Image.open(row.content_path).convert("RGB"))
        style   = self.tfm(Image.open(row.style_path).convert("RGB"))
        return content, style

VAL_BS = 32                                  
val_loader = DataLoader(ValPairDataset(args.val_csv, val_tfm),
                        batch_size=VAL_BS, shuffle=False,
                        num_workers=4, pin_memory=True)


@torch.no_grad()
def validate():
    model.eval()
    Lc_tot = Ls_tot = 0.
    for content, style in tqdm(val_loader, desc="Validating", total=len(val_loader), leave=False):        
        content = content.to(device, non_blocking=True)
        style   = style.to(device,   non_blocking=True)
        _, Lc, Ls, _, _ = model(content, style, mode="train")
        Lc_tot += Lc.item() * content.size(0)   # multiply by batch size
        Ls_tot += Ls.item() * content.size(0)
    N       = len(val_loader.dataset)
    Lc_avg  = Lc_tot / N
    Ls_avg  = Ls_tot / N
    score   = 7 * Lc_avg + 10 * Ls_avg
    model.train()
    return score, Lc_avg, Ls_avg

# Helper class for writing the metrics
class CsvLogger:
    def __init__(self, logdir):
        self.path = pathlib.Path(logdir) / "metrics.csv"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # write header once
        if not self.path.exists():
            with open(self.path, "w", newline="") as f:
                csv.writer(f).writerow(
                    ["time", "step", "tag", "value"])

    def add_scalar(self, tag, value, step):
        with open(self.path, "a", newline="") as f:
            csv.writer(f).writerow(
                [datetime.datetime.now().isoformat(), step, tag, value])

    def flush(self):          # keep API parity with TB writer
        pass


start_step  = 1               # default if no checkpoint
best_score  = float("inf")   
ckpt_path   = None  #pass from CLI

if ckpt_path:
    print(f" Resuming from {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location=device)

    #restore from checkpoint
    model.load_state_dict(ckpt["state_dict"])
    opt.load_state_dict(ckpt["opt_state"])
    start_step  = ckpt["step"] + 1       
    best_score  = ckpt.get("score", best_score)
    for state in opt.state.values():
        for k, v in state.items():
            if isinstance(v, torch.Tensor):
                state[k] = v.to(device, non_blocking=True)
else:
    print("No checkpoint found – training from scratch.")

# Initialize folder with experiments
os.makedirs("style_experiments", exist_ok=True)
writer      = CsvLogger(args.logdir)
best_score  = float("inf")


# loss weights from the paper
Wc, Ws, W1, W2 = 7., 10., 70., 1.


# Training loop 
progress = tqdm(range(start_step, args.steps + 1), dynamic_ncols=True)
for step in progress:
    content = next(content_iter).to(device, non_blocking=True)
    style   = next(style_iter).to(device,   non_blocking=True)

    # warm-up phase
    if step < 10000:                          
        warmup_learning_rate(opt, step)
    # decay phase
    else:                                      
        adjust_learning_rate(opt, step)

    out, Lc, Ls, Lid1, Lid2 = model(content, style, mode="train")
    loss = Wc*Lc + Ws*Ls + W1*Lid1 + W2*Lid2

    opt.zero_grad(set_to_none=True)
    loss.backward()
    opt.step()
    
    # write metrics
    if step % 1000 == 0:
        writer.add_scalar("train/total",   loss.item(), step)
        writer.add_scalar("train/Lc",      Lc.item(),   step)
        writer.add_scalar("train/Ls",      Ls.item(),   step)
        writer.add_scalar("train/lr",
                      opt.param_groups[0]["lr"],  # <-- replaced line
                      step)

    # display output images every 200 steps
    if step % 200 == 0:
        save_image(torch.cat([content[:8], style[:8], out.clamp(0,1)[:8]]), log_run_dir / 
                   f"sample_{step}.jpg", nrow=8)

    # validation step
    if step % args.val_every == 0:
        score, val_lc, val_ls = validate()
        writer.add_scalar("val/score", score, step)
        writer.add_scalar("val/Lc",    val_lc, step)
        writer.add_scalar("val/Ls",    val_ls, step)

        if score < best_score:
            best_score = score
            writer.add_scalar("val/best_score", best_score, step)
            torch.save({
                "step": step,
                "score": score,
                "state_dict": model.state_dict(),
                "opt_state":  opt.state_dict()
            }, exp_run_dir / "stytr2_best.pth")
            progress.write(f"New best score {score:.5f} at step {step}")

    # do periodic checkpoints
    if step % args.save_every == 0:
        torch.save(model.state_dict(), exp_run_dir /  f"stytr2_{step}.pth")

progress.close()
print("Training complete")