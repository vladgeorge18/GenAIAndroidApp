#!/usr/bin/env python

import re, pathlib

RUN_PATTERN = re.compile(r"run(\d+)$")

def next_run_dir(base: str) -> pathlib.Path:
    """
    Returns <base>/run{N+1} where N is the largest existing run number,
    creates the directory and returns the Path.
    """
    base_p = pathlib.Path(base)
    base_p.mkdir(parents=True, exist_ok=True)

    runs = [int(m.group(1)) for m in
            (RUN_PATTERN.match(p.name) for p in base_p.iterdir())
            if m]

    new_id = (max(runs) + 1) if runs else 1
    run_dir = base_p / f"run{new_id}"
    run_dir.mkdir()
    return run_dir

