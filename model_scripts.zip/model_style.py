#!/usr/bin/env python
import math, torch, torch.nn as nn
import torch.nn.functional as F
from torchvision.models import vgg19
from timm.layers import PatchEmbed                   


# Helper functions
def calc_mean_std(feat, eps=1e-5):
    size = feat.size()
    feat_var = feat.view(size[0], size[1], -1).var(dim=2) + eps
    feat_std = feat_var.sqrt().view(size[0], size[1], 1, 1)
    feat_mean = feat.view(size[0], size[1], -1).mean(dim=2).view(size[0], size[1], 1, 1)
    return feat_mean, feat_std

def adain(content_feat, style_feat):
    size = content_feat.size()
    content_mean, content_std = calc_mean_std(content_feat)
    style_mean,  style_std   = calc_mean_std(style_feat)
    normalized = (content_feat - content_mean.expand(size)) / content_std.expand(size)
    return normalized * style_std.expand(size) + style_mean.expand(size)

def _norm(feat, eps: float = 1e-5):
    #Instance-wise channel normalisation
    mean, std = calc_mean_std(feat, eps)
    return (feat - mean) / std


# CAPE - Content‑aware positional encoding class
class ContentAwarePE(nn.Module):
   
    def __init__(self, d_model, grid_sz=18):
        super().__init__()
        self.grid_sz = grid_sz
        self.learnable = nn.Parameter(torch.randn(1, d_model, grid_sz, grid_sz))
        self.proj      = nn.Conv2d(d_model, d_model, 1)

    def forward(self, feat):
        B, C, H, W = feat.shape
        pooled = F.adaptive_avg_pool2d(feat, self.grid_sz) 
        # content‑aware
        pos    = self.proj(pooled + self.learnable)             
        pos    = F.interpolate(pos, size=(H, W), mode='bilinear', align_corners=False)
        return pos


#Transformer Encoder Block Class

class TransformerBlock(nn.Module):
    def __init__(self, d_model=512, nhead=8, mlp_ratio=4., dropout=0.1):
        super().__init__()
        self.attn  = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)
        self.ln1   = nn.LayerNorm(d_model)
        self.mlp   = nn.Sequential(
            nn.Linear(d_model, int(d_model*mlp_ratio)), nn.ReLU(True),
            nn.Linear(int(d_model*mlp_ratio), d_model)
        )
        self.ln2   = nn.LayerNorm(d_model)

    def forward(self, x, key=None, value=None):
        k = key if key is not None else x
        v = value if value is not None else x
        x = x + self.attn(self.ln1(x), k, v, need_weights=False)[0]
        x = x + self.mlp(self.ln2(x))
        return x


# Transformer Decoder Block Class

class StyTr2DecoderLayer(nn.Module):
    

    def __init__(self, d_model=512, nhead=8, mlp_ratio=4., dropout=0.1):
        super().__init__()
        self.ln_q  = nn.LayerNorm(d_model)
        self.ln_kv = nn.LayerNorm(d_model)

        # first cross-attention layer
        self.attn1 = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)

        # second cross-attention layer
        self.attn2 = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=True)

        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(d_model, int(d_model*mlp_ratio)),
            nn.ReLU(True),
            nn.Linear(int(d_model*mlp_ratio), d_model)
        )

        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)
        self.ln3 = nn.LayerNorm(d_model)

    
    def forward(self, x_q, kv, cape):
        # First cross-attention
        _q = self.ln_q(x_q)
        _k = self.ln_kv(kv)
        out1 = self.attn1(_q, _k, _k, need_weights=False)[0]
        x = x_q + out1                        
        x = self.ln1(x)

        # add CAPE again, then second cross-attention
        x_cap = x + cape                      
        out2  = self.attn2(self.ln_q(x_cap), _k, _k, need_weights=False)[0]
        x = x + out2
        x = self.ln2(x)

        # FFN
        x = x + self.ffn(self.ln3(x))
        return x


# StyTr Model Class

class StyTr2(nn.Module):
    def __init__(self, d_model=512, depth=3, patch=8):
        super().__init__()
        # VGG–19 encoder 
        vgg = nn.Sequential(
        nn.Conv2d(3, 3, (1, 1)),
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(3, 64, (3, 3)),
        nn.ReLU(),  # relu1-1
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(64, 64, (3, 3)),
        nn.ReLU(),  # relu1-2
        nn.MaxPool2d((2, 2), (2, 2), (0, 0), ceil_mode=True),
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(64, 128, (3, 3)),
        nn.ReLU(),  # relu2-1
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(128, 128, (3, 3)),
        nn.ReLU(),  # relu2-2
        nn.MaxPool2d((2, 2), (2, 2), (0, 0), ceil_mode=True),
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(128, 256, (3, 3)),
        nn.ReLU(),  # relu3-1
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(256, 256, (3, 3)),
        nn.ReLU(),  # relu3-2
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(256, 256, (3, 3)),
        nn.ReLU(),  # relu3-3
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(256, 256, (3, 3)),
        nn.ReLU(),  # relu3-4
        nn.MaxPool2d((2, 2), (2, 2), (0, 0), ceil_mode=True),
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(256, 512, (3, 3)),
        nn.ReLU(),  # relu4-1, this is the last layer used
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu4-2
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu4-3
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu4-4
        nn.MaxPool2d((2, 2), (2, 2), (0, 0), ceil_mode=True),
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu5-1
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu5-2
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU(),  # relu5-3
        nn.ReflectionPad2d((1, 1, 1, 1)),
        nn.Conv2d(512, 512, (3, 3)),
        nn.ReLU()  # relu5-4
            )


        # load vgg normalized checkpoint
        state_dict = torch.load('./vgg_normalised.pth', map_location=lambda storage, loc: storage)
        vgg.load_state_dict(state_dict)
        layers = list(vgg.children())

        # Extract VGG intermediate feature maps
        self.enc_layers = nn.ModuleList([
            nn.Sequential(*layers[:4]),     # relu1-1
            nn.Sequential(*layers[4:11]),   # relu2-1
            nn.Sequential(*layers[11:18]),  # relu3-1
            nn.Sequential(*layers[18:31]),  # relu4-1
            nn.Sequential(*layers[31:44]),  # relu5-1
        ])

        # Freeze layers
        for p in self.enc_layers.parameters(): p.requires_grad_(False)

        # Patch embedding to convert image to tokens
        self.patch  = PatchEmbed(img_size= None, patch_size=patch, in_chans=3, embed_dim=d_model)

        # CAPE
        self.cape   = ContentAwarePE(d_model)

        # Content Transformer Encoder and Style Transformer Encoder
        self.content_enc = nn.ModuleList([TransformerBlock(d_model) for _ in range(depth)])
        self.style_enc   = nn.ModuleList([TransformerBlock(d_model) for _ in range(depth)])

        # Transformer Decoder Blocks
        self.decoder_blocks = nn.ModuleList([StyTr2DecoderLayer(d_model) for _ in range(depth)])

        # Upsample Convolution Decoder 
        self.conv_up = nn.Sequential(
            
            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.ReflectionPad2d(1),
            nn.Conv2d(d_model, 256, kernel_size=3, stride=1),
            nn.ReLU(True),

            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.ReflectionPad2d(1),
            nn.Conv2d(256, 128, kernel_size=3, stride=1),
            nn.ReLU(True),

            nn.Upsample(scale_factor=2, mode='nearest'),
            nn.ReflectionPad2d(1),
            nn.Conv2d(128,  64, kernel_size=3, stride=1),
            nn.ReLU(True),

            nn.Conv2d(64, 3, kernel_size=1)
        )
        # MSE loss
        self.mse = nn.MSELoss()

    

    def _encode_feats(self, x):

        # pass input through selected VGG encoder layers to extract the feature maps

        feats = []
        for block in self.enc_layers:
            x = block(x)
            feats.append(x)
        return feats

    def forward(self, content, style, *, mode="train"):
        

        # Tokenize image into transformer tokens 
        def _tokenise(img):
            patch_feats = self.patch(img)            # B × N × C
            B, N, C = patch_feats.shape
            h = w = int(math.sqrt(N))
            # reshape to spatial map for CAPE
            patch_feats = patch_feats.view(B, h, w, C).permute(0,3,1,2)  # B×C×h×w
            cape = self.cape(patch_feats)                                # B×C×h×w
            # # flatten  and add CAPE
            tokens = (patch_feats + cape).flatten(2).transpose(1,2)      # B×N×C
            cape_tok = cape.flatten(2).transpose(1,2)                    # B×N×C
            return tokens, cape_tok

        ctok, cape_tokens = _tokenise(content)
        stok, cape_s     = _tokenise(style)

        # Pass content image through the Transformer Encoder Blocks
        for blk in self.content_enc: 
            ctok = blk(ctok)

        # Pass style image through the Transformer Encoder Blocks
        for blk in self.style_enc:   
            stok = blk(stok)

        
        # Transformer Decoder Block (Q=content, K,V=style)
        x = ctok
        for blk in self.decoder_blocks:
            x = blk(x, kv=stok, cape=cape_tokens)

        # reshape back to feature map
        B, N, C = x.shape
        h = w = int(math.sqrt(N))
        x = x.transpose(1,2).view(B, C, h, w)    # B×C×h×w
        
        # final RGB
        out = self.conv_up(x)        

        if mode == "test":
            return out.clamp(0,1)


        ### Compute losses for training

        # extract VGG features of content, style, and output
        c_feats      = self._encode_feats(content)
        s_feats      = self._encode_feats(style)
        out_feats    = self._encode_feats(out)

        # Compute content loss using normalized relu4-1 & relu3-1 features
        Lc = self.mse(_norm(out_feats[3]), _norm(c_feats[3])) + self.mse(_norm(out_feats[2]), _norm(c_feats[2]))

        # Compute style loss (mean+std over all 5 feature levels)
        Ls = torch.tensor(0., device=out.device)
        for f_o, f_s in zip(out_feats, s_feats):
            mu_o,  sigma_o  = calc_mean_std(f_o)
            mu_s,  sigma_s  = calc_mean_std(f_s)
            Ls += self.mse(mu_o,  mu_s) + self.mse(sigma_o, sigma_s)

        # Compute identity losses

        def _decode(q_tok, kv_tok,  cape_tok):
            x = q_tok
            for blk in self.decoder_blocks:          # same blocks used above
                x = blk(x, kv_tok,  cape = cape_tok)            # Q = q_tok, K,V = kv_tok
            return x
        
        # Pass through Transformer decoder blocks and Up Convolution
        ic_tok = _decode(ctok, ctok, cape_tokens)     # content to content
        is_tok = _decode(stok, stok, cape_s)          # style to style

        B_t, N_t, C_t = ic_tok.shape
        h_t = w_t = int(math.sqrt(N_t))

        Icc = self.conv_up(ic_tok.transpose(1, 2)
                              .view(B_t, C_t, h_t, w_t)).clamp(0, 1)
        Iss = self.conv_up(is_tok.transpose(1, 2)
                              .view(B_t, C_t, h_t, w_t)).clamp(0, 1)
        
        # Compute pixel level identity loss
        Lid1 = self.mse(Icc, content) + self.mse(Iss, style)

        # Compute feature level identity loss
        Icc_f = self._encode_feats(Icc)
        Iss_f = self._encode_feats(Iss)
        Lid2 = sum(self.mse(f1, f2) for f1, f2 in zip(Icc_f, c_feats)) + sum(self.mse(f1, f2) for f1, f2 in zip(Iss_f, s_feats))

        return out, Lc, Ls, Lid1, Lid2